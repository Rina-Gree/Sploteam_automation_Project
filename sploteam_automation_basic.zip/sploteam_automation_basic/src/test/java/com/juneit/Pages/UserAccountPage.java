package com.juneit.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;




public class UserAccountPage {
    private WebDriver driver;
    public UserAccountPage(WebDriver driver) {
        this.driver = driver;
    }

    public List<WebElement> getNotificationsGroup() {
        List<WebElement> getNotificationsGroup = driver.findElements(By.className(NOTIFICATION_LIST_GROUP_CLASS));
        return getNotificationsGroup;
    }
    public WebElement assertNamePage() {
        WebElement assertNamePage = driver.findElement(By.xpath(NAME_ACCOUNT_PAGE_XPATH));
        return assertNamePage;
    }
    public WebElement getNewNotificationCount() {
        WebElement getNewNotificationCount = driver.findElement(By.xpath(NEW_NOTIFICATION_XPATH));
        return getNewNotificationCount;
    }
    public  int getcount(){
        List<WebElement> notifications = driver.findElements(By.className(NOTIFICATION_LIST_CLASS));
        return notifications.size();
    }
    public  void printNotification(){
        List<WebElement> notifications = driver.findElements(By.className(NOTIFICATION_LIST_CLASS));
        System.out.println("Количество уведомлений" + notifications.size());
    }
    public WebElement CheckBox() {
        WebElement CheckBox = driver.findElement(By.xpath(CHECK_BOX_XPATH));
        return CheckBox;
    }
    public boolean isCheckBoxSelected() {; // найти чек-бокс на странице
        return CheckBox().isSelected();
    }
    public void toggleCheckBox() {;  //выбрать чек-бокс
        CheckBox().click();
    }
    public WebElement deleteNotificationButton() {  //удалить
        WebElement deleteNotificationButton = driver.findElement(By.xpath(NOTIFICATION_DELETE_XPATH));
        return deleteNotificationButton;
    }
    public WebElement readNotificationButton() {  //прочитать
        WebElement readNotificationButton = driver.findElement(By.xpath(NOTIFICATION_READ_XPATH));
        return readNotificationButton;
    }
    public WebElement changeAllNotificationButton() {  //выбрать все
        WebElement changeAllNotificationButton = driver.findElement(By.xpath(NOTIFICATION_ALL_READ_XPATH));
        return changeAllNotificationButton;
    }

    public WebElement messageNotFondNotification() { //сообщение, что уведомлений нет
        WebElement messageNotFondNotification = driver.findElement(By.xpath(NOTIFICATION_NOT_FOUND_XPATH));
        return messageNotFondNotification;
    }
    public WebElement eventsGroupNotification() { //События
        WebElement eventsGroupNotification = driver.findElement(By.xpath(EVENTS_NOTIFICATION_XPATH));
        return eventsGroupNotification;
    }
    public List<WebElement> checkBoxNotificationListElement() { //
       List<WebElement> checkBoxNotificationListElement = driver.findElements(By.className(CHECK_BOX_LIST_LIST_CLASS));
        return checkBoxNotificationListElement;
    }


    public static final String NAME_ACCOUNT_PAGE_XPATH = "//*[@id=\"root\"]/div[2]/div/div[2]";
    public static final String NOTIFICATION_LIST_GROUP_CLASS = "NotificationGroupsNav_categories__1Qsqm";
    public static final String NEW_NOTIFICATION_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[1]/div/div[2]/div[2]";

    public static final String NOTIFICATION_LIST_CLASS = "Notification_notification___WK9I";

    public static final String CHECK_BOX_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/div[1]/label/span";
    public static final String NOTIFICATION_DELETE_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]";

    public static final String NOTIFICATION_READ_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]";
    public static final String NOTIFICATION_ALL_READ_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[1]/div[1]/label";
    public static final String NOTIFICATION_NOT_FOUND_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[2]/div";
    public static final String EVENTS_NOTIFICATION_XPATH = "//*[@id=\"root\"]/div[2]/div/div[3]/div[2]/div/div/div[1]/div/div[3]/div[1]";

    public static final String CHECK_BOX_LIST_LIST_CLASS = "FlatOrangeCheckbox_checkbox__3PiR2";

}