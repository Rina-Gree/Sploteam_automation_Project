package com.juneit;


import com.juneit.Pages.EventsPage;
import com.juneit.Pages.MainPage;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import static org.junit.Assert.*;
import java.util.Calendar;
import  java.util.List;
import  java.util.concurrent.TimeUnit;


public class SploteamTestPOM {
    private final PropertiesLoader properties = new PropertiesLoader();
    private final WebDriver driver = new ChromeDriver();
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    MainPage mainPage = new MainPage(driver);
    EventsPage eventsPage = new EventsPage(driver);

    @Before
    public void setup() {
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        ((HasAuthentication) driver).register(UsernameAndPassword.of(properties.username,
                properties.password));
        driver.get(properties.baseUrl);
    }

    @After
    public void close() {
        driver.close();
    }

    @Test
    public void assertMainPageIsLoaded() {
        assertTrue(mainPage.getSignInButton().isDisplayed());
        assertTrue(mainPage.getLogoHeader().isDisplayed());
    }

    @Test
    public void assertCreateGameTabOpen() {
        mainPage.getCreateGameButton().click();
        for (int i = 0; i < eventsPage.getEventsAndCreateGamesTabs().size(); i++) {
            if (eventsPage.getEventsAndCreateGamesTabs().get(i).getAttribute("class").contains("active")) {
                assertEquals("Создать игру", eventsPage.getEventsAndCreateGamesTabs().get(i).getText());
            }
        }
    }

    @Test
    public void assertEventsTabOpen() {
        mainPage.getMoreGamesButton().click();
        for (int i = 0; i < eventsPage.getEventsAndCreateGamesTabs().size(); i++) {
            if (eventsPage.getEventsAndCreateGamesTabs().get(i).getAttribute("class").contains("active")) {
                assertEquals("События", eventsPage.getEventsAndCreateGamesTabs().get(i).getText());
            }
        }
    }

    @Test
    public void CreateGameIfNotLogin() {
        mainPage.getCreateGameButton().click();
        eventsPage.getFirstDate().click();
        eventsPage.getDropdownArena().click();
        eventsPage.changeArenaName().click();
        eventsPage.ChangeTimeForGame().click();
        eventsPage.getChangeGamesButton().click();
        assertTrue(eventsPage.getLoginWindow().isDisplayed());
    }

    @Test
    public void CreateGameForTver() {
        mainPage.getCreateGameButton().click();
        Assert.assertTrue(eventsPage.getCityList().isDisplayed());
        eventsPage.getCityList().click();
        eventsPage.getCityTverChange().click();
        eventsPage.getCalendarForCreateGame();
        for (int i = 0; i < eventsPage.getCalendarForCreateGame().size(); i++) {
            assertTrue(eventsPage.getTimeSlotsForCreateGames().isDisplayed());
//            wait(3);
//            if
//            (driver.findElement(eventsPage.getTimeSlotsForCreateGames).isEmpty()){
//                assertEquals("Нет доступных вариантов. Попробуйте изменить дату или фильтр.", eventsPage.getTextIfNotCardsForGames().getText());
//            assertTrue(eventsPage.getTextIfNotCardsForGames().isDisplayed());

        }
    }

    @Test
    public void AssertThatFirstSlotOfCalendarIsToday() {
        mainPage.getCreateGameButton().click();
        eventsPage.getTodayDate().click();
        assertTrue(eventsPage.getTodayDate().isDisplayed());
        assertEquals("Сегодня", eventsPage.getTodayDate().getText());


    }

//    @Test
//    public void ChangeTomorrowDate() {
//
//        mainPage.getCreateGameButton().click();
//        eventsPage.getFirstDate().click();
//        eventsPage.getDropdownArena().click();
//
//        for (int i = 0; i<2; i++){
//            assertEquals("Песок", eventsPage.changeArenaName().getText());
//        };
//        eventsPage.changeArenaName().click();
//        for (int i = 0; i < eventsPage.getBeginTimeForEveryCard().size(); i++){
//            assertEquals("09:00", eventsPage.getAssertBeginTimeForEveryCard().getText());
//            assertTrue(eventsPage.getBeginTimeForEveryCard().isDisplayed());
//        }



    }



